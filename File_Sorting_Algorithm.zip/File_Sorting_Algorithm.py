import shutil
import os
import mimetypes

# Gets the file type
def get_file_type(file_path):
    file_type, _ = mimetypes.guess_type(file_path)
    return str(file_type)

#gets the current full directory
current_directory = os.getcwd()
absolute_path = os.path.abspath(current_directory)

# Gets the directory of the downloads folder
downloads_folder_directory = os.path.dirname(absolute_path)

# To store the names of the different folders that the files can be sorted into
folders = ['Videos', 'Audio', 'Pictures', 'Documents', 'Applications', 'Misc']

# Iterates over the folders in the downloads folder
for folder in folders:
    # Stores the full directory for the current file sorting folder
    new_folder_path = os.path.join(downloads_folder_directory, folder)
    # Checks if the folder exists in the downloads directory
    if not os.path.exists(new_folder_path):
        # Adds the folder if it does not exists
        os.mkdir(new_folder_path)
        print(folder + ' folder created successfully')
    else:
        print(folder + ' already exists')

# Stores the amount of each file type
videos = 0
audio_files = 0
pictures = 0
applications = 0
documents = 0
miscellaneous = 0

# Iterates over each file in the folder
for filename in os.listdir(downloads_folder_directory):
    file_path = os.path.join(downloads_folder_directory, filename)
    if os.path.isfile(file_path):
        # Gets the file type
        file_type = get_file_type(file_path)
        final_file_type = file_type[:4]
        # Checks what the file type is and moves the file to the appropriate folder
        if final_file_type == 'vide':
            parent_folder = os.path.dirname(file_path)

            video_folder = os.path.join(parent_folder, 'Videos')

            shutil.move(file_path, video_folder)
            videos += 1
        elif final_file_type == 'audi':
            parent_folder = os.path.dirname(file_path)

            audio_folder = os.path.join(parent_folder, "Audio")

            shutil.move(file_path, audio_folder)
            audio_files += 1
        elif final_file_type == 'imag':
            parent_folder = os.path.dirname(file_path)

            pictures_folder = os.path.join(parent_folder, "Pictures")

            shutil.move(file_path, pictures_folder)
            pictures += 1
        elif final_file_type == 'appl':

            parent_folder = os.path.dirname(file_path)

            if get_file_type(file_path) == 'application/x-msdownload':

                application_folder = os.path.join(parent_folder, 'Applications')

                shutil.move(file_path, application_folder)
                applications += 1
            else:

                document_folder = os.path.join(parent_folder, 'Documents')

                shutil.move(file_path, document_folder)
                documents += 1
        elif final_file_type == 'None':
            parent_folder = os.path.dirname(file_path)

            miscellaneous_folder = os.path.join(parent_folder, 'Misc')

            shutil.move(file_path, miscellaneous_folder)
            miscellaneous += 1
        #print(get_file_type(file_path))

# Stores the amount of files for each file type in string form so it can be returned to the user
number_of_videos = str(videos)
number_of_audio_files = str(audio_files)
number_of_pictures = str(pictures)
number_of_applications = str(applications)
number_of_documents = str(documents)
number_of_miscellaneous_files = str(miscellaneous)

# Returns the amount of files that was moved for each file type to the user
print(number_of_videos + ' videos moved to Videos')
print(number_of_audio_files + ' audio files moved to Audio')
print(number_of_pictures + ' pictures moved to Pictures')
print(number_of_applications + ' applications moved to Applications')
print(number_of_documents + ' documents moved to Documents')
print(number_of_miscellaneous_files + ' miscellaneous files moved to Misc')